// JavaScript for ConnectorListEdit component
